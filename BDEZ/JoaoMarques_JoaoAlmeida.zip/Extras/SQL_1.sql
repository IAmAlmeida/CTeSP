Select DATE_FORMAT(ALU_DNSC, "%w, %d - %M - %y, dia num %j de %y") from alunos;
